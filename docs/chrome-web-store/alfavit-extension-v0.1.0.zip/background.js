// ../../packages/engine/dist/detect.js
var CYRILLIC = /[Ѐ-ӿԀ-ԯ]/;
var LATIN = /[A-Za-zÇçŞşĞğŎŏÖöʻ']/;
function classify(ch) {
  if (CYRILLIC.test(ch))
    return "cyrillic";
  if (LATIN.test(ch))
    return "old-latin";
  return "foreign";
}
function segment(text) {
  const runs = [];
  let start = 0;
  while (start < text.length) {
    const script = classify(text[start]);
    let end = start + 1;
    while (end < text.length && classify(text[end]) === script)
      end++;
    runs.push({ text: text.slice(start, end), script, start, end });
    start = end;
  }
  return runs;
}

// ../../packages/engine/dist/normalize.js
var APOSTROPHE_VARIANTS = /[''‘’'ʼʹ`´]/g;
function normalizeApostrophes(text) {
  return text.replace(APOSTROPHE_VARIANTS, "\u02BB");
}

// ../../packages/engine/dist/case.js
function applyCase(template, sourceFirstChar) {
  const isUpper = sourceFirstChar !== sourceFirstChar.toLowerCase();
  if (!isUpper)
    return template;
  return template.length > 1 ? template[0].toUpperCase() + template.slice(1) : template.toUpperCase();
}

// ../../packages/engine/dist/mappings/old-latin.js
var OLD_LATIN_DIGRAPHS = [
  ["o\u02BB", "\u014F"],
  ["g\u02BB", "\u011F"],
  ["sh", "\u015F"],
  ["ch", "\xE7"]
];

// ../../packages/engine/dist/convert-old-latin.js
function convertOldLatin(text) {
  const src = normalizeApostrophes(text);
  const lower = src.toLowerCase();
  let out = "";
  let i = 0;
  outer: while (i < src.length) {
    for (const [from, to] of OLD_LATIN_DIGRAPHS) {
      if (lower.startsWith(from, i)) {
        out += applyCase(to, src[i]);
        i += from.length;
        continue outer;
      }
    }
    out += src[i];
    i++;
  }
  return out;
}

// ../../packages/engine/dist/mappings/cyrillic.js
var CYRILLIC_MAP = {
  \u0430: "a",
  \u0431: "b",
  \u0432: "v",
  \u0433: "g",
  \u0434: "d",
  \u0435: "e",
  \u0436: "j",
  \u0437: "z",
  \u0438: "i",
  \u0439: "y",
  \u043A: "k",
  \u043B: "l",
  \u043C: "m",
  \u043D: "n",
  \u043E: "o",
  \u043F: "p",
  \u0440: "r",
  \u0441: "s",
  \u0442: "t",
  \u0443: "u",
  \u0444: "f",
  \u0445: "x",
  \u0448: "\u015F",
  \u0447: "\xE7",
  \u0451: "yo",
  \u044E: "yu",
  \u044F: "ya",
  \u044D: "e",
  \u045E: "\u014F",
  \u0493: "\u011F",
  \u049B: "q",
  \u04B3: "h",
  \u044A: "\u02BC",
  \u044C: ""
};

// ../../packages/engine/dist/convert-cyrillic.js
var CYRILLIC_VOWELS = /* @__PURE__ */ new Set([..."\u0430\u0435\u0451\u0438\u043E\u0443\u045E\u044D\u044E\u044F\u0410\u0415\u0401\u0418\u041E\u0423\u040E\u042D\u042E\u042F"]);
function convertCyrillicRun(text, offset) {
  const flags = [];
  let output = "";
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const lower = ch.toLowerCase();
    const prev = i > 0 ? text[i - 1] : "";
    const wordInitial = i === 0 || !CYRILLIC_VOWELS.has(prev) && !/[а-яё]/i.test(prev);
    if (lower === "\u0435") {
      const afterVowelOrSign = CYRILLIC_VOWELS.has(prev) || prev === "\u044A" || prev === "\u044C";
      const useYe = wordInitial || afterVowelOrSign;
      const chosen = useYe ? "ye" : "e";
      output += applyCase(chosen, ch);
      flags.push({
        start: offset + i,
        end: offset + i + 1,
        chosen,
        alternatives: [useYe ? "e" : "ye"],
        reason: "cyrillic-e-position"
      });
      continue;
    }
    if (lower === "\u0446") {
      const chosen = "s";
      output += applyCase(chosen, ch);
      flags.push({
        start: offset + i,
        end: offset + i + 1,
        chosen,
        alternatives: ["c"],
        reason: "cyrillic-ts"
      });
      continue;
    }
    const mapped = CYRILLIC_MAP[lower];
    output += mapped !== void 0 ? applyCase(mapped, ch) : ch;
  }
  return { output, flags };
}

// ../../packages/engine/dist/dictionary.js
var EXCEPTIONS = {
  \u0446\u0438\u0440\u043A: "sirk"
};
function lookupException(word) {
  const hit = EXCEPTIONS[word.toLowerCase()];
  if (hit === void 0)
    return void 0;
  const isUpper = word[0] !== word[0].toLowerCase();
  return isUpper ? hit[0].toUpperCase() + hit.slice(1) : hit;
}

// ../../packages/engine/dist/types.js
function emptyResult() {
  return { text: "", segments: [], flags: [] };
}

// ../../packages/engine/dist/transliterate.js
function transliterate(input, _options = {}) {
  if (input.length === 0)
    return emptyResult();
  const segments = [];
  const flags = [];
  for (const run of segment(input)) {
    if (run.script === "foreign") {
      segments.push({ ...run, source: run.text, output: run.text });
      continue;
    }
    const exception = lookupException(run.text);
    if (exception !== void 0) {
      segments.push({ source: run.text, output: exception, script: run.script, start: run.start, end: run.end });
      continue;
    }
    if (run.script === "old-latin") {
      const output = convertOldLatin(run.text);
      segments.push({ source: run.text, output, script: run.script, start: run.start, end: run.end });
    } else {
      const { output, flags: runFlags } = convertCyrillicRun(run.text, run.start);
      flags.push(...runFlags);
      segments.push({ source: run.text, output, script: run.script, start: run.start, end: run.end });
    }
  }
  return { text: segments.map((s) => s.output).join(""), segments, flags };
}

// src/convert.ts
function toNewLatin(text) {
  return transliterate(text).text;
}

// src/inject.ts
function applyConversion(converted) {
  const el = document.activeElement;
  const tag = el?.tagName;
  if (el && (tag === "INPUT" || tag === "TEXTAREA")) {
    const field = el;
    const start = field.selectionStart ?? field.value.length;
    const end = field.selectionEnd ?? field.value.length;
    const next = field.value.slice(0, start) + converted + field.value.slice(end);
    const proto = tag === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter) setter.call(field, next);
    else field.value = next;
    field.selectionStart = field.selectionEnd = start + converted.length;
    field.dispatchEvent(new Event("input", { bubbles: true }));
    return;
  }
  if (el && el.isContentEditable) {
    document.execCommand("insertText", false, converted);
    return;
  }
  void navigator.clipboard.writeText(converted).catch(() => {
  });
  const toast = document.createElement("div");
  toast.textContent = "Copied \u2014 new Latin";
  toast.style.cssText = "position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#000;color:#fff;padding:10px 16px;border-radius:999px;font:14px sans-serif;z-index:2147483647;opacity:.95";
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 1800);
}

// src/background.ts
var MENU_ID = "alfavit-convert";
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_ID,
    title: "Convert to new Latin",
    contexts: ["selection"]
  });
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== MENU_ID || !tab?.id || !info.selectionText) return;
  const converted = toNewLatin(info.selectionText);
  void chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: applyConversion,
    args: [converted]
  });
});
