// ../../packages/engine/dist/normalize.js
var APOSTROPHE_VARIANTS = "'\u2018\u2019\u02BC\u02B9`\xB4";
var RE = new RegExp(`[${APOSTROPHE_VARIANTS}]`, "g");
function normalizeApostrophes(text) {
  return text.replace(RE, "\u02BB");
}

// ../../packages/engine/dist/detect.js
var CYRILLIC = /[Ѐ-ӿԀ-ԯ]/;
var LATIN = new RegExp(`[A-Za-z\xC7\xE7\u015E\u015F\u011E\u011F\u014E\u014F\xD6\xF6\u02BB${APOSTROPHE_VARIANTS}]`);
function classify(ch) {
  if (CYRILLIC.test(ch))
    return "cyrillic";
  if (LATIN.test(ch))
    return "old-latin";
  return "foreign";
}
function segment(text) {
  const runs = [];
  let start = 0;
  while (start < text.length) {
    const script = classify(text[start]);
    let end = start + 1;
    while (end < text.length && classify(text[end]) === script)
      end++;
    runs.push({ text: text.slice(start, end), script, start, end });
    start = end;
  }
  return runs;
}

// ../../packages/engine/dist/case.js
function applyCase(template, sourceFirstChar) {
  const isUpper = sourceFirstChar !== sourceFirstChar.toLowerCase();
  if (!isUpper)
    return template;
  return template.length > 1 ? template[0].toUpperCase() + template.slice(1) : template.toUpperCase();
}

// ../../packages/engine/dist/mappings/old-latin.js
var OLD_LATIN_DIGRAPHS = [
  ["o\u02BB", "\xF6"],
  ["g\u02BB", "\u011F"],
  ["sh", "\u015F"],
  ["ch", "\xE7"],
  ["\u014F", "\xF6"],
  // MUST STAY LAST. Normalization folds every apostrophe-like mark to the
  // turned comma ʻ (U+02BB) so oʻ/gʻ match above regardless of how the user
  // typed them. Whatever turned comma is left over was NOT part of oʻ/gʻ, so it
  // is a tutuq belgisi — emit it as ʼ (U+02BC), the reformed alphabet's one and
  // only apostrophe sign. U+02BB never appears in new-Latin output; matching
  // the Cyrillic side, where ъ → ʼ (U+02BC).
  ["\u02BB", "\u02BC"]
];

// ../../packages/engine/dist/convert-old-latin.js
function convertOldLatin(text) {
  const src = normalizeApostrophes(text);
  const lower = src.toLowerCase();
  let out = "";
  let i = 0;
  outer: while (i < src.length) {
    for (const [from, to] of OLD_LATIN_DIGRAPHS) {
      if (lower.startsWith(from, i)) {
        out += applyCase(to, src[i]);
        i += from.length;
        continue outer;
      }
    }
    out += src[i];
    i++;
  }
  return out;
}

// ../../packages/engine/dist/mappings/cyrillic.js
var CYRILLIC_MAP = {
  \u0430: "a",
  \u0431: "b",
  \u0432: "v",
  \u0433: "g",
  \u0434: "d",
  \u0435: "e",
  \u0436: "j",
  \u0437: "z",
  \u0438: "i",
  \u0439: "y",
  \u043A: "k",
  \u043B: "l",
  \u043C: "m",
  \u043D: "n",
  \u043E: "o",
  \u043F: "p",
  \u0440: "r",
  \u0441: "s",
  \u0442: "t",
  \u0443: "u",
  \u0444: "f",
  \u0445: "x",
  \u0448: "\u015F",
  \u0447: "\xE7",
  \u0451: "yo",
  \u044E: "yu",
  \u044F: "ya",
  \u044D: "e",
  \u045E: "\xF6",
  \u0493: "\u011F",
  \u049B: "q",
  \u04B3: "h",
  \u044A: "\u02BC",
  \u044C: ""
};

// ../../packages/engine/dist/convert-cyrillic.js
var CYRILLIC_VOWELS = /* @__PURE__ */ new Set([..."\u0430\u0435\u0451\u0438\u043E\u0443\u045E\u044D\u044E\u044F\u0410\u0415\u0401\u0418\u041E\u0423\u040E\u042D\u042E\u042F"]);
function convertCyrillicRun(text, offset) {
  const flags = [];
  let output2 = "";
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const lower = ch.toLowerCase();
    const prev = i > 0 ? text[i - 1] : "";
    const wordInitial = i === 0 || !CYRILLIC_VOWELS.has(prev) && !/[а-яё]/i.test(prev);
    if (lower === "\u0435") {
      const afterVowelOrSign = CYRILLIC_VOWELS.has(prev) || prev === "\u044A" || prev === "\u044C";
      const useYe = wordInitial || afterVowelOrSign;
      const chosen = useYe ? "ye" : "e";
      output2 += applyCase(chosen, ch);
      flags.push({
        start: offset + i,
        end: offset + i + 1,
        chosen,
        alternatives: [useYe ? "e" : "ye"],
        reason: "cyrillic-e-position"
      });
      continue;
    }
    if (lower === "\u0446") {
      const chosen = "s";
      output2 += applyCase(chosen, ch);
      flags.push({
        start: offset + i,
        end: offset + i + 1,
        chosen,
        alternatives: ["c"],
        reason: "cyrillic-ts"
      });
      continue;
    }
    const mapped = CYRILLIC_MAP[lower];
    output2 += mapped !== void 0 ? applyCase(mapped, ch) : ch;
  }
  return { output: output2, flags };
}

// ../../packages/engine/dist/dictionary.js
var EXCEPTIONS = {
  \u0446\u0438\u0440\u043A: "sirk"
};
function lookupException(word) {
  const hit = EXCEPTIONS[word.toLowerCase()];
  if (hit === void 0)
    return void 0;
  const isUpper = word[0] !== word[0].toLowerCase();
  return isUpper ? hit[0].toUpperCase() + hit.slice(1) : hit;
}
var S_H_STEMS = [
  { cyrillic: "\u0438\u0441\u04B3\u043E\u049B", oldLatin: "ishoq" },
  { cyrillic: "\u0438\u0441\u04B3\u043E\u043B", oldLatin: "ishol" },
  { cyrillic: "\u0430\u0441\u04B3\u043E\u0431", oldLatin: "ashob" },
  { cyrillic: "\u043C\u0443\u0441\u04B3\u0430\u0444", oldLatin: "mushaf" },
  { cyrillic: "\u0442\u0430\u0441\u04B3\u0438\u04B3", oldLatin: "tashih" }
];
var APOSTROPHES = /* @__PURE__ */ new Set([...APOSTROPHE_VARIANTS, "\u02BB", "\u02BC"]);
var STEMS = S_H_STEMS.map(({ cyrillic, oldLatin }) => ({
  oldLatin,
  output: convertCyrillicRun(cyrillic, 0).output
})).sort((a, b) => b.oldLatin.length - a.oldLatin.length);
function matchedLength(word, stem) {
  let i = 0;
  for (let j = 0; j < stem.length; j++) {
    if (stem[j] === "h" && stem[j - 1] === "s" && APOSTROPHES.has(word[i]))
      i++;
    if (word[i]?.toLowerCase() !== stem[j])
      return void 0;
    i++;
  }
  return i;
}
function caseLike(source, output2) {
  const letters = [...source].filter((ch) => ch.toLowerCase() !== ch.toUpperCase());
  if (letters.length > 1 && letters.every((ch) => ch === ch.toUpperCase()))
    return output2.toUpperCase();
  if (source[0] !== source[0].toLowerCase())
    return output2[0].toUpperCase() + output2.slice(1);
  return output2;
}
function matchSHStem(word) {
  for (const stem of STEMS) {
    const sourceLength = matchedLength(word, stem.oldLatin);
    if (sourceLength !== void 0) {
      return { sourceLength, output: caseLike(word.slice(0, sourceLength), stem.output) };
    }
  }
  return void 0;
}

// ../../packages/engine/dist/protect.js
var TLDS = /* @__PURE__ */ new Set(["uz", "ru", "com", "org", "net", "io", "dev", "app", "info", "me", "tv", "co", "gov", "edu", "kz", "tj", "kg", "ly", "be", "asia", "su", "by"]);
var URL_PATTERNS = [/\b(?:https?|ftp):\/\/[^\s<>"]+/gi, /\bwww\.[^\s<>"]+/gi];
var HANDLE = /(?<![A-Za-z0-9._%+-])@[A-Za-z0-9_]{3,32}\b/g;
var EMAIL = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$/;
var LOCAL_CHAR = /[A-Za-z0-9._%+-]/;
var DOMAIN_CHAR = /[A-Za-z0-9.-]/;
var MAX_LOCAL = 64;
var MAX_DOMAIN = 253;
var MAX_PATH = 2048;
var ENDING = /\.([A-Za-z]{2,24})(?![A-Za-z0-9-])/g;
var HOST_CHAR = /[A-Za-z0-9.-]/;
var PATH_END = /[\s<>"]/;
function trimEnd(text, start, end) {
  const span = text.slice(start, end);
  const hasParen = span.includes("(");
  const hasBracket = span.includes("[");
  while (end > start) {
    const last = text[end - 1];
    if (/[.,;:!?]/.test(last) || last === ")" && !hasParen || last === "]" && !hasBracket)
      end--;
    else
      break;
  }
  return end;
}
function emails(text, found) {
  for (let at = text.indexOf("@"); at !== -1; at = text.indexOf("@", at + 1)) {
    let start = at;
    while (start > 0 && at - start < MAX_LOCAL && LOCAL_CHAR.test(text[start - 1]))
      start--;
    let end = at + 1;
    while (end < text.length && end - at <= MAX_DOMAIN && DOMAIN_CHAR.test(text[end]))
      end++;
    while (end > at + 1 && /[.-]/.test(text[end - 1]))
      end--;
    if (start < at && EMAIL.test(text.slice(start, end)))
      found.push({ start, end });
  }
}
function bareDomains(text, found) {
  let covered = 0;
  for (const m of text.matchAll(ENDING)) {
    const dot = m.index;
    let end = dot + m[0].length;
    if (dot < covered)
      continue;
    const hasPath = text[end] === "/";
    if (!hasPath && !TLDS.has(m[1].toLowerCase()))
      continue;
    let start = dot;
    while (start > 0 && dot - start < MAX_DOMAIN && HOST_CHAR.test(text[start - 1]))
      start--;
    while (start < dot && /[.-]/.test(text[start]))
      start++;
    if (start === dot || text[start - 1] === "@")
      continue;
    if (hasPath) {
      while (end < text.length && end - dot < MAX_PATH && !PATH_END.test(text[end]))
        end++;
      end = trimEnd(text, start, end);
    }
    found.push({ start, end });
    covered = end;
  }
}
function findProtectedSpans(text) {
  const found = [];
  for (const pattern of URL_PATTERNS) {
    for (const m of text.matchAll(pattern)) {
      const end = trimEnd(text, m.index, m.index + m[0].length);
      if (end > m.index)
        found.push({ start: m.index, end });
    }
  }
  emails(text, found);
  bareDomains(text, found);
  for (const m of text.matchAll(HANDLE))
    found.push({ start: m.index, end: m.index + m[0].length });
  found.sort((a, b) => a.start - b.start);
  const merged = [];
  for (const span of found) {
    const last = merged[merged.length - 1];
    if (last && span.start <= last.end)
      last.end = Math.max(last.end, span.end);
    else
      merged.push({ ...span });
  }
  return merged;
}

// ../../packages/engine/dist/types.js
function emptyResult() {
  return { text: "", segments: [], flags: [] };
}

// ../../packages/engine/dist/transliterate.js
function isForeignLatinWord(word) {
  const lower = word.toLowerCase();
  return lower.includes("w") || /c(?!h)/.test(lower);
}
var APOSTROPHES2 = /* @__PURE__ */ new Set([...APOSTROPHE_VARIANTS, "\u02BB", "\u02BC"]);
function firstApostrophe(word) {
  for (let i = 0; i < word.length; i++)
    if (APOSTROPHES2.has(word[i]))
      return i;
  return word.length;
}
function convertText(text, offset, segments, flags) {
  for (const local of segment(text)) {
    const run = { ...local, start: local.start + offset, end: local.end + offset };
    if (run.script === "foreign") {
      segments.push({ ...run, source: run.text, output: run.text });
      continue;
    }
    const exception = lookupException(run.text);
    if (exception !== void 0) {
      segments.push({ source: run.text, output: exception, script: run.script, start: run.start, end: run.end });
      continue;
    }
    if (run.script === "old-latin") {
      const stem = matchSHStem(run.text);
      if (stem) {
        const output3 = stem.output + convertOldLatin(run.text.slice(stem.sourceLength));
        segments.push({ source: run.text, output: output3, script: run.script, start: run.start, end: run.end });
        continue;
      }
      const head = run.text.slice(0, firstApostrophe(run.text));
      if (isForeignLatinWord(head)) {
        const converted = convertOldLatin(head);
        if (converted !== head) {
          flags.push({ start: run.start, end: run.start + head.length, chosen: head, alternatives: [converted], reason: "foreign-word" });
        }
        const output3 = head + convertOldLatin(run.text.slice(head.length));
        segments.push({ source: run.text, output: output3, script: run.script, start: run.start, end: run.end });
        continue;
      }
      const output2 = convertOldLatin(run.text);
      segments.push({ source: run.text, output: output2, script: run.script, start: run.start, end: run.end });
    } else {
      const { output: output2, flags: runFlags } = convertCyrillicRun(run.text, run.start);
      flags.push(...runFlags);
      segments.push({ source: run.text, output: output2, script: run.script, start: run.start, end: run.end });
    }
  }
}
function transliterate(input2, _options = {}) {
  if (input2.length === 0)
    return emptyResult();
  const segments = [];
  const flags = [];
  let cursor = 0;
  for (const span of findProtectedSpans(input2)) {
    if (span.start > cursor)
      convertText(input2.slice(cursor, span.start), cursor, segments, flags);
    const source = input2.slice(span.start, span.end);
    segments.push({ source, output: source, script: "foreign", start: span.start, end: span.end });
    cursor = span.end;
  }
  if (cursor < input2.length)
    convertText(input2.slice(cursor), cursor, segments, flags);
  return { text: segments.map((s) => s.output).join(""), segments, flags };
}

// src/convert.ts
function toNewLatin(text) {
  return transliterate(text).text;
}

// src/popup.ts
var input = document.getElementById("in");
var output = document.getElementById("out");
var copyBtn = document.getElementById("copy");
function render() {
  output.value = toNewLatin(input.value);
}
input.addEventListener("input", render);
copyBtn.addEventListener("click", () => {
  void navigator.clipboard.writeText(output.value).then(() => {
    copyBtn.textContent = "Copied";
    setTimeout(() => copyBtn.textContent = "Copy", 1200);
  });
});
